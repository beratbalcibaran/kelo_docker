# Marvelmind vs OptiTrack analizi
Kayit: `kayit_20261112_181048_test2_zfiltre.csv`  rigid body id=1  hedgehog adres=7  kaynak=ultrasonik konum
Sure: 180 s. Motive yukari ekseni: z. OptiTrack 120 Hz, gecerli oran 100.0%

## 1. Hiz (update rate)
- Gelen paket: 1040, gecerli: 824 (79.2%), ayni konum tekrar: 5
- Ortalama gecerli hiz: **5.77 Hz**; aralik medyan 173 ms, p95 177 ms, max 0.35 s
- 2 s den uzun bosluk (MM_LOST tetikler): 0 kez, toplam 0.0 s
- Iletim gecikmesi dalgalanmasi (PC varis - cihaz zaman damgasi, min a gore): medyan 1 ms, p95 5 ms

## 2. Hizalama (Marvelmind <- OptiTrack, 2D)
- Bulunan durma sayisi: 5 (hiz < 0.02 m/s, donus < 3.0 deg/s, en az 10 s, uclar 2 s kirpildi)
- Sicrama ayiklama: durmalarda medyandan > 20 cm (ya da 5 MAD) uzak 0 ornek hizalama ve sapma hesabindan cikarildi
- Hizalama verisi: durma noktalari, 538 ornek
- Donus -133.40 deg, oteleme (2.348, -3.399) m, ayna=hayir, robust RMS 14.2 cm
- Hedgehog ofseti (rigid body pivotuna gore, veriden): (0.106, 0.094) m, |o|=0.142 m

## 3. Durma testi
|   nokta |   t_bas |   t_son |   sure_s |   n_mm |   hz |   gecersiz |   sicrama |   sapma_x_cm |   sapma_y_cm |   sapma_cm |   titresim_std_cm |   titresim_p95_cm |   hata_p95_cm |   hata_max_cm |   max_bosluk_s |   sapma_loo_cm |
|--------:|--------:|--------:|---------:|-------:|-----:|-----------:|----------:|-------------:|-------------:|-----------:|------------------:|------------------:|--------------:|--------------:|---------------:|---------------:|
|       1 |     2.3 |    22.4 |     20.2 |    116 | 5.76 |          0 |         0 |         -1.4 |        -21.5 |       21.5 |               0.4 |               0.6 |          21.9 |          22   |           0.18 |           27.8 |
|       2 |    38.9 |    63.3 |     24.3 |    140 | 5.76 |          0 |         0 |          0.6 |         -1.1 |        1.2 |               0.4 |               0.6 |           1.7 |           1.8 |           0.18 |           35   |
|       3 |    74.6 |    98.2 |     23.6 |    137 | 5.8  |          0 |         0 |         15.2 |          0.4 |       15.2 |               0.4 |               0.6 |          15.6 |          15.7 |           0.18 |           44   |
|       4 |   109.2 |   134.2 |     25   |    145 | 5.79 |          0 |         0 |         -6.1 |         10.7 |       12.4 |               0.4 |               0.6 |          12.9 |          13   |           0.18 |           36.3 |
|       5 |   145.3 |   177.9 |     32.6 |      0 | 0    |        188 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |

- Sabit sapma: ortalama 12.6 cm, en kotu 21.5 cm
- Sabit sapma (birini-disarida-birak, daha durust): ortalama 35.8 cm, en kotu 44.0 cm
- Titresim (std): ortalama 0.4 cm, en kotu 0.4 cm
- Duruken hiz: ortalama 4.62 Hz
- Sicrama (> 20 cm): 0 / 538 ornek (0.0%), 0 noktada; en kotu 0 (1. nokta)
- Nokta arasi mesafe (hizalamadan bagimsiz, 6 cift): MM - OPT farki RMS 10.4 cm, en kotu 23.4 cm, olcek 1.201

## 4. Surus testi
Yeterli hareketli ornek yok.

## 5. Karar icin ozet (kaba esikler, robota gore yorumla)
- Dururken dogrulama: en kotu sapma 44.0 cm, titresim 0.4 cm -> SINIRDA/ZAYIF (sapma > 10 cm ya da titresim > 5 cm)
- LOST sonrasi yeniden konumlandirma: dururken 43 ornek/10 s 
- mm_monitor (2 s timeout) bu kayitta 0 kez MM_LOST derdi.

Grafikler: yol.png, hata_zaman.png, hiz.png, durma_dagilim.png, gecikme.png
