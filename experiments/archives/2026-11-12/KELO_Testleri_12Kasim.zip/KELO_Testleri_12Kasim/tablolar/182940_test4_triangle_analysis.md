# Marvelmind vs OptiTrack analizi
Kayit: `kayit_20261112_182940_test4_triangle_zfiltre.csv`  rigid body id=1  hedgehog adres=7  kaynak=ultrasonik konum
Sure: 708 s. Motive yukari ekseni: z. OptiTrack 110 Hz, gecerli oran 88.2%

## 1. Hiz (update rate)
- Gelen paket: 4091, gecerli: 2090 (51.1%), ayni konum tekrar: 19
- Ortalama gecerli hiz: **3.20 Hz**; aralik medyan 173 ms, p95 177 ms, max 148.09 s
- 2 s den uzun bosluk (MM_LOST tetikler): 5 kez, toplam 291.7 s
- Iletim gecikmesi dalgalanmasi (PC varis - cihaz zaman damgasi, min a gore): medyan 2 ms, p95 6 ms

## 2. Hizalama (Marvelmind <- OptiTrack, 2D)
- Bulunan durma sayisi: 15 (hiz < 0.02 m/s, donus < 3.0 deg/s, en az 10 s, uclar 2 s kirpildi)
- Sicrama ayiklama: durmalarda medyandan > 20 cm (ya da 5 MAD) uzak 0 ornek hizalama ve sapma hesabindan cikarildi
- Hizalama verisi: durma noktalari, 1198 ornek
- Donus 174.12 deg, oteleme (1.448, -3.053) m, ayna=hayir, robust RMS 6.8 cm
- Hedgehog ofseti (rigid body pivotuna gore, veriden): (-0.699, -0.311) m, |o|=0.764 m

## 3. Durma testi
|   nokta |   t_bas |   t_son |   sure_s |   n_mm |   hz |   gecersiz |   sicrama |   sapma_x_cm |   sapma_y_cm |   sapma_cm |   titresim_std_cm |   titresim_p95_cm |   hata_p95_cm |   hata_max_cm |   max_bosluk_s |   sapma_loo_cm |
|--------:|--------:|--------:|---------:|-------:|-----:|-----------:|----------:|-------------:|-------------:|-----------:|------------------:|------------------:|--------------:|--------------:|---------------:|---------------:|
|       1 |    31.1 |    55   |     23.9 |    138 | 5.79 |          0 |         0 |         -2.7 |          8.6 |        9.1 |               0.4 |               0.6 |           9.5 |           9.6 |           0.18 |           11   |
|       2 |    65.7 |    93.2 |     27.4 |    158 | 5.76 |          0 |         0 |         -7.6 |          3.7 |        8.5 |               0.4 |               0.6 |           8.9 |           9.1 |           0.18 |           10.7 |
|       3 |   112.9 |   146.7 |     33.8 |      0 | 0    |        196 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       4 |   173.6 |   184.8 |     11.1 |     64 | 5.75 |          0 |         0 |          2.6 |          2.4 |        3.5 |               0.4 |               0.6 |           4.2 |           4.4 |           0.18 |            3.8 |
|       5 |   209.9 |   245   |     35.1 |      0 | 0    |        203 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       6 |   266.2 |   292.9 |     26.7 |      0 | 0    |        155 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       7 |   318.3 |   343.5 |     25.3 |      0 | 0    |        146 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       8 |   355   |   386   |     31   |    179 | 5.77 |          0 |         0 |          9.3 |          0.4 |        9.3 |               0.4 |               0.6 |           9.8 |           9.8 |           0.19 |           10.9 |
|       9 |   401.9 |   428.7 |     26.8 |      0 | 0    |        154 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      10 |   451.8 |   476.2 |     24.5 |    141 | 5.76 |          0 |         0 |          5.2 |          0.7 |        5.3 |               0.4 |               0.6 |           5.8 |           7   |           0.2  |            6.5 |
|      11 |   487.6 |   525.8 |     38.2 |    220 | 5.77 |          0 |         0 |         -3.2 |         -5.9 |        6.7 |               0.4 |               0.6 |           7.2 |           7.4 |           0.18 |            8.4 |
|      12 |   540.6 |   569.3 |     28.7 |      0 | 0    |        166 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      13 |   602   |   627.4 |     25.3 |    146 | 5.76 |          0 |         0 |          2.3 |         -1.4 |        2.7 |               0.4 |               0.6 |           3.2 |           3.4 |           0.18 |            4.4 |
|      14 |   638.5 |   664.9 |     26.4 |    152 | 5.75 |          0 |         0 |         -1.1 |         -2.6 |        2.8 |               0.4 |               0.6 |           3.2 |           3.3 |           0.19 |            3.4 |
|      15 |   679.7 |   706.3 |     26.6 |      0 | 0    |        153 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |

- Sabit sapma: ortalama 6.0 cm, en kotu 9.3 cm
- Sabit sapma (birini-disarida-birak, daha durust): ortalama 7.4 cm, en kotu 11.0 cm
- Titresim (std): ortalama 0.4 cm, en kotu 0.4 cm
- Duruken hiz: ortalama 3.07 Hz
- Sicrama (> 20 cm): 0 / 1198 ornek (0.0%), 0 noktada; en kotu 0 (1. nokta)
- Nokta arasi mesafe (hizalamadan bagimsiz, 28 cift): MM - OPT farki RMS 7.0 cm, en kotu 11.5 cm, olcek 1.018

## 4. Surus testi
- Hareketli ornek: 218 (hiz > 0.05 m/s), ortalama hiz 0.35 m/s
- Tahmini gecikme: **0.83 s** (OptiTrack a gore Marvelmind bu kadar geride)
- Capraz kontrol (gecikme + ofset birlikte, tum veri): gecikme 1.50 s, ofset (-0.314, -0.153) m
  UYARI: iki gecikme tahmini 0.1 s den fazla farkli. Hedgehog ofseti yanlis olabilir (--offset kontrol et ya da pivotu hedgehoga koy).
- Hareket halindeki hata (robotun gordugu, gecikme dahil): RMS 57.5 cm, p95 116.8 cm, max 147.6 cm
- Gecikme duzeltilirse kalan hata: RMS nan cm, p95 105.3 cm
- Gecikmenin 0.25 m/s de yarattigi hata: ~20.8 cm
- Yol boyu hata ortalamasi -31.5 cm (eksi = geride), yanal 24.6 cm
- Hiza gore hata:
  - 0.05-0.10 m/s: n=7, RMS 48.1 cm (gecikme duzeltilmis nan cm)
  - 0.10-0.20 m/s: n=13, RMS 52.5 cm (gecikme duzeltilmis nan cm)
  - 0.20-0.30 m/s: n=13, RMS 49.3 cm (gecikme duzeltilmis 46.8 cm)
  - 0.30-0.50 m/s: n=185, RMS 58.7 cm (gecikme duzeltilmis 48.4 cm)

## 5. Karar icin ozet (kaba esikler, robota gore yorumla)
- Dururken dogrulama: en kotu sapma 11.0 cm, titresim 0.4 cm -> SINIRDA/ZAYIF (sapma > 10 cm ya da titresim > 5 cm)
- Surekli kullanim: 3.2 Hz, gecikme 0.83 s, hareket p95 117 cm -> onerilmez (yavas/gecikmeli/hatali); AMCL e surekli sokmak yerine dururken ya da LOST durumunda kullan
- LOST sonrasi yeniden konumlandirma: dururken 29 ornek/10 s 
- mm_monitor (2 s timeout) bu kayitta 5 kez MM_LOST derdi.

Grafikler: yol.png, hata_zaman.png, hiz.png, durma_dagilim.png, gecikme.png
