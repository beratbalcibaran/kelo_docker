# Marvelmind vs OptiTrack analizi
Kayit: `kayit_20261112_180719_test1_zfiltre.csv`  rigid body id=1  hedgehog adres=7  kaynak=ultrasonik konum
Sure: 190 s. Motive yukari ekseni: z. OptiTrack 120 Hz, gecerli oran 100.0%

## 1. Hiz (update rate)
- Gelen paket: 1095, gecerli: 1046 (95.5%), ayni konum tekrar: 7
- Ortalama gecerli hiz: **5.52 Hz**; aralik medyan 173 ms, p95 176 ms, max 8.14 s
- 2 s den uzun bosluk (MM_LOST tetikler): 1 kez, toplam 8.1 s
- Iletim gecikmesi dalgalanmasi (PC varis - cihaz zaman damgasi, min a gore): medyan 1 ms, p95 4 ms

## 2. Hizalama (Marvelmind <- OptiTrack, 2D)
- Bulunan durma sayisi: 4 (hiz < 0.02 m/s, donus < 3.0 deg/s, en az 10 s, uclar 2 s kirpildi)
- Sicrama ayiklama: durmalarda medyandan > 20 cm (ya da 5 MAD) uzak 0 ornek hizalama ve sapma hesabindan cikarildi
- Hizalama verisi: durma noktalari, 782 ornek
- Donus 116.75 deg, oteleme (2.363, -3.014) m, ayna=evet, robust RMS 10.0 cm
- Hedgehog ofseti (rigid body pivotuna gore, veriden): (-0.050, 0.099) m, |o|=0.111 m
  UYARI: ayna cikti. Motive yukari ekseni yanlis secilmis olabilir (--up dene).

## 3. Durma testi
|   nokta |   t_bas |   t_son |   sure_s |   n_mm |   hz |   gecersiz |   sicrama |   sapma_x_cm |   sapma_y_cm |   sapma_cm |   titresim_std_cm |   titresim_p95_cm |   hata_p95_cm |   hata_max_cm |   max_bosluk_s |   sapma_loo_cm |
|--------:|--------:|--------:|---------:|-------:|-----:|-----------:|----------:|-------------:|-------------:|-----------:|------------------:|------------------:|--------------:|--------------:|---------------:|---------------:|
|       1 |    12.5 |    54.6 |     42.1 |    243 | 5.77 |          0 |         0 |         -2.5 |          2.8 |        3.7 |               0.4 |               0.6 |           4.1 |           4.3 |           0.18 |           27.7 |
|       2 |    67.9 |    93.7 |     25.7 |    148 | 5.75 |          0 |         0 |          9.2 |         -8.3 |       12.4 |               0.4 |               0.6 |          12.9 |          13.1 |           0.18 |           15.7 |
|       3 |   108   |   133.7 |     25.7 |    149 | 5.79 |          0 |         0 |        -17.3 |          4.8 |       18   |               0.4 |               0.6 |          18.5 |          18.6 |           0.18 |           21.8 |
|       4 |   145.3 |   187.4 |     42.1 |    242 | 5.75 |          1 |         0 |          2.9 |         -2.2 |        3.7 |               0.6 |               0.6 |           4.1 |           4.2 |           0.35 |           13.4 |

- Sabit sapma: ortalama 9.5 cm, en kotu 18.0 cm
- Sabit sapma (birini-disarida-birak, daha durust): ortalama 19.7 cm, en kotu 27.7 cm
- Titresim (std): ortalama 0.5 cm, en kotu 0.6 cm
- Duruken hiz: ortalama 5.76 Hz
- Sicrama (> 20 cm): 0 / 782 ornek (0.0%), 0 noktada; en kotu 0 (1. nokta)
- Nokta arasi mesafe (hizalamadan bagimsiz, 6 cift): MM - OPT farki RMS 9.3 cm, en kotu 14.9 cm, olcek 0.982

## 4. Surus testi
Yeterli hareketli ornek yok.

## 5. Karar icin ozet (kaba esikler, robota gore yorumla)
- Dururken dogrulama: en kotu sapma 27.7 cm, titresim 0.6 cm -> SINIRDA/ZAYIF (sapma > 10 cm ya da titresim > 5 cm)
- LOST sonrasi yeniden konumlandirma: dururken 58 ornek/10 s 
- mm_monitor (2 s timeout) bu kayitta 1 kez MM_LOST derdi.

Grafikler: yol.png, hata_zaman.png, hiz.png, durma_dagilim.png, gecikme.png
