# Marvelmind vs OptiTrack analizi
Kayit: `kayit_20261112_185141_test5_in_out1_zfiltre.csv`  rigid body id=1  hedgehog adres=7  kaynak=ultrasonik konum
Sure: 2146 s. Motive yukari ekseni: z. OptiTrack 69 Hz, gecerli oran 57.7%

## 1. Hiz (update rate)
- Gelen paket: 12392, gecerli: 6847 (55.3%), ayni konum tekrar: 59
- Ortalama gecerli hiz: **3.19 Hz**; aralik medyan 173 ms, p95 176 ms, max 50.40 s
- 2 s den uzun bosluk (MM_LOST tetikler): 44 kez, toplam 944.8 s
- Iletim gecikmesi dalgalanmasi (PC varis - cihaz zaman damgasi, min a gore): medyan 5 ms, p95 8 ms

## 2. Hizalama (Marvelmind <- OptiTrack, 2D)
- Bulunan durma sayisi: 29 (hiz < 0.02 m/s, donus < 3.0 deg/s, en az 10 s, uclar 2 s kirpildi)
- Sicrama ayiklama: durmalarda medyandan > 20 cm (ya da 5 MAD) uzak 0 ornek hizalama ve sapma hesabindan cikarildi
- Hizalama verisi: durma noktalari, 2537 ornek
- Donus 176.18 deg, oteleme (1.844, -3.707) m, ayna=hayir, robust RMS 14.2 cm
- Hedgehog ofseti (rigid body pivotuna gore, veriden): (0.297, -0.249) m, |o|=0.388 m

## 3. Durma testi
|   nokta |   t_bas |   t_son |   sure_s |   n_mm |   hz |   gecersiz |   sicrama |   sapma_x_cm |   sapma_y_cm |   sapma_cm |   titresim_std_cm |   titresim_p95_cm |   hata_p95_cm |   hata_max_cm |   max_bosluk_s |   sapma_loo_cm |
|--------:|--------:|--------:|---------:|-------:|-----:|-----------:|----------:|-------------:|-------------:|-----------:|------------------:|------------------:|--------------:|--------------:|---------------:|---------------:|
|       1 |    18.7 |    41.4 |     22.6 |    131 | 5.78 |          0 |         0 |          1.7 |         18.7 |       18.8 |               0.4 |               0.6 |          19.3 |          19.3 |           0.18 |           20.7 |
|       2 |    52.7 |    79.1 |     26.4 |    152 | 5.76 |          0 |         0 |         -2.9 |         -3.1 |        4.3 |               0.4 |               0.6 |           4.7 |           4.9 |           0.18 |            4.8 |
|       3 |   251.5 |   274.1 |     22.6 |    130 | 5.75 |          0 |         0 |         -0.1 |         18.5 |       18.5 |               0.4 |               0.6 |          19   |          19   |           0.18 |           20.9 |
|       4 |   285.2 |   313.5 |     28.3 |      0 | 0    |        163 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       5 |   412.5 |   438.5 |     26   |      0 | 0    |        150 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       6 |   449   |   475.5 |     26.5 |    153 | 5.77 |          0 |         0 |          0.6 |         -4.5 |        4.6 |               0.4 |               0.6 |           5   |           5.1 |           0.18 |            6.1 |
|       7 |   601.4 |   633.8 |     32.4 |    187 | 5.77 |          0 |         0 |         10.1 |          5.5 |       11.5 |               0.4 |               0.6 |          12.1 |          12.2 |           0.18 |           12.4 |
|       8 |   646.7 |   673.2 |     26.5 |    153 | 5.78 |          0 |         0 |          2.2 |        -12   |       12.2 |               0.4 |               0.6 |          12.7 |          12.8 |           0.18 |           13.9 |
|       9 |   700.9 |   712.5 |     11.5 |      0 | 0    |         66 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      10 |   816.4 |   847.7 |     31.3 |    181 | 5.78 |          0 |         0 |          6.8 |          0.7 |        6.8 |               0.4 |               0.6 |           7.3 |           7.4 |           0.18 |            7.9 |
|      11 |   859.5 |   901.1 |     41.7 |      0 | 0    |        241 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      12 |   937.8 |   964   |     26.3 |      0 | 0    |        152 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      13 |  1049.7 |  1077.4 |     27.8 |    160 | 5.77 |          0 |         0 |          1.2 |          0.3 |        1.2 |               0.4 |               0.6 |           1.7 |           1.9 |           0.18 |            1.6 |
|      14 |  1089.3 |  1115.7 |     26.4 |    152 | 5.76 |          0 |         0 |        -12.5 |         15.4 |       19.8 |               0.4 |               0.6 |          20.2 |          20.4 |           0.18 |           21.5 |
|      15 |  1131   |  1159.1 |     28   |    162 | 5.78 |          0 |         0 |          1.3 |         -0.1 |        1.3 |               0.4 |               0.6 |           1.9 |           2   |           0.18 |            1.5 |
|      16 |  1258.7 |  1283.3 |     24.6 |      0 | 0    |        142 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      17 |  1292.3 |  1318.5 |     26.2 |    151 | 5.76 |          0 |         0 |          0.2 |         -9.2 |        9.2 |               0.4 |               0.6 |           9.7 |           9.7 |           0.18 |           10.9 |
|      18 |  1339.2 |  1373.1 |     33.9 |      0 | 0    |        195 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      19 |  1439.4 |  1466   |     26.6 |    154 | 5.78 |          0 |         0 |        -16.7 |         37.7 |       41.2 |               0.4 |               0.6 |          41.6 |          41.8 |           0.18 |           43.4 |
|      20 |  1474.6 |  1509   |     34.4 |    198 | 5.76 |          0 |         0 |          0.6 |         -7.3 |        7.4 |               0.4 |               0.6 |           7.8 |           7.8 |           0.18 |            9.4 |
|      21 |  1522.6 |  1536   |     13.4 |     77 | 5.73 |          0 |         0 |         -0.8 |         -4.9 |        5   |               0.4 |               0.6 |           5.4 |           5.5 |           0.18 |            5.3 |
|      22 |  1540.1 |  1552.5 |     12.4 |     72 | 5.82 |          0 |         0 |         -0.7 |         -4.8 |        4.8 |               0.4 |               0.6 |           5.4 |           5.5 |           0.18 |            5.1 |
|      23 |  1639.1 |  1665   |     26   |      0 | 0    |        150 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      24 |  1674   |  1703.9 |     29.9 |      0 | 0    |        172 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      25 |  1714.2 |  1741.1 |     27   |      0 | 0    |        155 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      26 |  1876.6 |  1904   |     27.4 |    159 | 5.79 |          0 |         0 |         -1.7 |          4.9 |        5.2 |               0.4 |               0.6 |           5.6 |           5.7 |           0.18 |            6.6 |
|      27 |  1932.1 |  1958.4 |     26.3 |      0 | 0    |        152 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      28 |  2080.1 |  2104.4 |     24.3 |      0 | 0    |        140 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|      29 |  2115.5 |  2144.1 |     28.6 |    165 | 5.76 |          0 |         0 |         -3.8 |         -4.3 |        5.8 |               0.4 |               0.6 |           6.2 |           6.4 |           0.18 |            6.8 |

- Sabit sapma: ortalama 10.4 cm, en kotu 41.2 cm
- Sabit sapma (birini-disarida-birak, daha durust): ortalama 11.7 cm, en kotu 43.4 cm
- Titresim (std): ortalama 0.4 cm, en kotu 0.4 cm
- Duruken hiz: ortalama 3.38 Hz
- Sicrama (> 20 cm): 0 / 2537 ornek (0.0%), 0 noktada; en kotu 0 (1. nokta)
- Nokta arasi mesafe (hizalamadan bagimsiz, 136 cift): MM - OPT farki RMS 10.9 cm, en kotu 43.8 cm, olcek 1.013

## 4. Surus testi
- Hareketli ornek: 549 (hiz > 0.05 m/s), ortalama hiz 0.42 m/s
- Tahmini gecikme: **0.09 s** (OptiTrack a gore Marvelmind bu kadar geride)
- Capraz kontrol (gecikme + ofset birlikte, tum veri): gecikme 0.12 s, ofset (0.281, -0.245) m
- Hareket halindeki hata (robotun gordugu, gecikme dahil): RMS 18.4 cm, p95 41.2 cm, max 52.2 cm
- Gecikme duzeltilirse kalan hata: RMS 17.8 cm, p95 40.2 cm
- Gecikmenin 0.25 m/s de yarattigi hata: ~2.2 cm
- Yol boyu hata ortalamasi -4.4 cm (eksi = geride), yanal 10.2 cm
- Hiza gore hata:
  - 0.05-0.10 m/s: n=35, RMS 23.2 cm (gecikme duzeltilmis 23.2 cm)
  - 0.10-0.20 m/s: n=49, RMS 20.6 cm (gecikme duzeltilmis 20.7 cm)
  - 0.20-0.30 m/s: n=57, RMS 16.8 cm (gecikme duzeltilmis 16.4 cm)
  - 0.30-0.50 m/s: n=275, RMS 16.8 cm (gecikme duzeltilmis 16.2 cm)
  - 0.50-2.00 m/s: n=133, RMS 19.9 cm (gecikme duzeltilmis 18.7 cm)

## 5. Karar icin ozet (kaba esikler, robota gore yorumla)
- Dururken dogrulama: en kotu sapma 43.4 cm, titresim 0.4 cm -> SINIRDA/ZAYIF (sapma > 10 cm ya da titresim > 5 cm)
- Surekli kullanim: 3.2 Hz, gecikme 0.09 s, hareket p95 41 cm -> onerilmez (yavas/gecikmeli/hatali); AMCL e surekli sokmak yerine dururken ya da LOST durumunda kullan
- LOST sonrasi yeniden konumlandirma: dururken 33 ornek/10 s 
- mm_monitor (2 s timeout) bu kayitta 44 kez MM_LOST derdi.

Grafikler: yol.png, hata_zaman.png, hiz.png, durma_dagilim.png, gecikme.png
