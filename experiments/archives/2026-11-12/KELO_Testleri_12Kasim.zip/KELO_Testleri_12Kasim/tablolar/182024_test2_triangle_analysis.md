# Marvelmind vs OptiTrack analizi
Kayit: `kayit_20261112_182024_test2_triangle_zfiltre.csv`  rigid body id=1  hedgehog adres=7  kaynak=ultrasonik konum
Sure: 469 s. Motive yukari ekseni: z. OptiTrack 112 Hz, gecerli oran 92.3%

## 1. Hiz (update rate)
- Gelen paket: 2709, gecerli: 1789 (66.0%), ayni konum tekrar: 10
- Ortalama gecerli hiz: **4.52 Hz**; aralik medyan 173 ms, p95 178 ms, max 42.78 s
- 2 s den uzun bosluk (MM_LOST tetikler): 3 kez, toplam 84.5 s
- Iletim gecikmesi dalgalanmasi (PC varis - cihaz zaman damgasi, min a gore): medyan 2 ms, p95 7 ms

## 2. Hizalama (Marvelmind <- OptiTrack, 2D)
- Bulunan durma sayisi: 10 (hiz < 0.02 m/s, donus < 3.0 deg/s, en az 10 s, uclar 2 s kirpildi)
- Sicrama ayiklama: durmalarda medyandan > 20 cm (ya da 5 MAD) uzak 0 ornek hizalama ve sapma hesabindan cikarildi
- Hizalama verisi: durma noktalari, 1071 ornek
- Donus -90.09 deg, oteleme (1.036, -4.903) m, ayna=evet, robust RMS 22.6 cm
- Hedgehog ofseti (rigid body pivotuna gore, veriden): (0.432, -1.331) m, |o|=1.400 m
  UYARI: ayna cikti. Motive yukari ekseni yanlis secilmis olabilir (--up dene).

## 3. Durma testi
|   nokta |   t_bas |   t_son |   sure_s |   n_mm |   hz |   gecersiz |   sicrama |   sapma_x_cm |   sapma_y_cm |   sapma_cm |   titresim_std_cm |   titresim_p95_cm |   hata_p95_cm |   hata_max_cm |   max_bosluk_s |   sapma_loo_cm |
|--------:|--------:|--------:|---------:|-------:|-----:|-----------:|----------:|-------------:|-------------:|-----------:|------------------:|------------------:|--------------:|--------------:|---------------:|---------------:|
|       1 |     2.3 |    17.7 |     15.5 |      0 | 0    |         89 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       2 |    61.8 |    88.9 |     27   |    156 | 5.78 |          0 |         0 |        -15.9 |         38.5 |       41.6 |               0.4 |               0.6 |          42.2 |          42.3 |           0.18 |           55   |
|       3 |    97.1 |   125.1 |     28   |    161 | 5.75 |          0 |         0 |          7.1 |        -16.9 |       18.3 |               0.4 |               0.6 |          18.8 |          18.9 |           0.18 |           21.8 |
|       4 |   142   |   169.2 |     27.1 |      0 | 0    |        157 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       5 |   186   |   214   |     28   |    162 | 5.79 |          0 |         0 |         16.7 |         -3.1 |       17   |               0.4 |               0.6 |          17.4 |          17.6 |           0.19 |           51.8 |
|       6 |   223.8 |   251.3 |     27.4 |    159 | 5.79 |          0 |         0 |         -1   |          0.8 |        1.3 |               0.4 |               0.6 |           2.2 |           2.4 |           0.19 |            4   |
|       7 |   269.1 |   293.4 |     24.3 |      0 | 0    |        140 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |
|       8 |   324.4 |   351.9 |     27.5 |    159 | 5.78 |          0 |         0 |         22.8 |         10.3 |       25.1 |               0.4 |               0.6 |          25.6 |          25.7 |           0.2  |           57   |
|       9 |   364.6 |   412   |     47.4 |    274 | 5.79 |          0 |         0 |        -16.5 |         -1.7 |       16.6 |               0.4 |               0.6 |          16.9 |          17   |           0.19 |           24.1 |
|      10 |   440.1 |   457.1 |     17   |      0 | 0    |         98 |         0 |        nan   |        nan   |      nan   |             nan   |             nan   |         nan   |         nan   |         nan    |          nan   |

- Sabit sapma: ortalama 20.0 cm, en kotu 41.6 cm
- Sabit sapma (birini-disarida-birak, daha durust): ortalama 35.6 cm, en kotu 57.0 cm
- Titresim (std): ortalama 0.4 cm, en kotu 0.4 cm
- Duruken hiz: ortalama 3.47 Hz
- Sicrama (> 20 cm): 0 / 1071 ornek (0.0%), 0 noktada; en kotu 0 (1. nokta)
- Nokta arasi mesafe (hizalamadan bagimsiz, 15 cift): MM - OPT farki RMS 23.5 cm, en kotu 46.3 cm, olcek 1.102

## 4. Surus testi
- Hareketli ornek: 121 (hiz > 0.05 m/s), ortalama hiz 0.46 m/s
- Tahmini gecikme: **0.00 s** (OptiTrack a gore Marvelmind bu kadar geride)
- Capraz kontrol (gecikme + ofset birlikte, tum veri): gecikme 0.38 s, ofset (-0.176, 0.160) m
  UYARI: iki gecikme tahmini 0.1 s den fazla farkli. Hedgehog ofseti yanlis olabilir (--offset kontrol et ya da pivotu hedgehoga koy).
- Hareket halindeki hata (robotun gordugu, gecikme dahil): RMS 150.7 cm, p95 310.4 cm, max 331.1 cm
- Gecikme duzeltilirse kalan hata: RMS 150.7 cm, p95 310.4 cm
- Gecikmenin 0.25 m/s de yarattigi hata: ~0.0 cm
- Yol boyu hata ortalamasi -30.6 cm (eksi = geride), yanal 70.8 cm
- Hiza gore hata:
  - 0.05-0.10 m/s: n=18, RMS 122.3 cm (gecikme duzeltilmis 122.3 cm)
  - 0.10-0.20 m/s: n=16, RMS 126.9 cm (gecikme duzeltilmis 126.9 cm)
  - 0.20-0.30 m/s: n=11, RMS 178.2 cm (gecikme duzeltilmis 178.2 cm)
  - 0.30-0.50 m/s: n=15, RMS 108.4 cm (gecikme duzeltilmis 108.4 cm)
  - 0.50-2.00 m/s: n=61, RMS 166.7 cm (gecikme duzeltilmis 166.7 cm)

## 5. Karar icin ozet (kaba esikler, robota gore yorumla)
- Dururken dogrulama: en kotu sapma 57.0 cm, titresim 0.4 cm -> SINIRDA/ZAYIF (sapma > 10 cm ya da titresim > 5 cm)
- Surekli kullanim: 4.5 Hz, gecikme 0.00 s, hareket p95 310 cm -> onerilmez (yavas/gecikmeli/hatali); AMCL e surekli sokmak yerine dururken ya da LOST durumunda kullan
- LOST sonrasi yeniden konumlandirma: dururken 40 ornek/10 s 
- mm_monitor (2 s timeout) bu kayitta 3 kez MM_LOST derdi.

Grafikler: yol.png, hata_zaman.png, hiz.png, durma_dagilim.png, gecikme.png
